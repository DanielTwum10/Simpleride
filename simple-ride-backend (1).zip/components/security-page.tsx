"use client"

import { useState } from "react"
import { CheckCircle2, Shield, Clock, Cpu, Package, TestTube } from "lucide-react"
import { cn } from "@/lib/utils"

type TabKey = "middleware" | "jobs" | "testing" | "docker" | "env"

const tabs: { key: TabKey; label: string; icon: typeof Shield }[] = [
  { key: "middleware", label: "Security Middleware", icon: Shield },
  { key: "jobs", label: "Background Jobs", icon: Clock },
  { key: "testing", label: "Testing", icon: TestTube },
  { key: "docker", label: "Docker & CI/CD", icon: Cpu },
  { key: "env", label: "Environment Variables", icon: Package },
]

const CODE: Record<TabKey, { label: string; code: string }[]> = {
  middleware: [
    {
      label: "middleware/auth.ts",
      code: `import { Request, Response, NextFunction } from 'express'
import jwt from 'jsonwebtoken'
import { redis } from '../config/redis'

export interface JwtPayload {
  id: string; role: string; jti: string; iat: number; exp: number
}

// ── Access Token Verification ────────────────────────────────
export const authenticate = async (req: Request, res: Response, next: NextFunction) => {
  const header = req.headers.authorization
  if (!header?.startsWith('Bearer ')) {
    return res.status(401).json({ code: 'UNAUTHORIZED', message: 'Missing token' })
  }
  const token = header.slice(7)
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as JwtPayload
    // Check token blacklist (logout)
    const blacklisted = await redis.exists(\`blacklist:\${decoded.jti}\`)
    if (blacklisted) {
      return res.status(401).json({ code: 'TOKEN_REVOKED', message: 'Token has been revoked' })
    }
    req.user = decoded
    next()
  } catch (err) {
    const msg = err instanceof jwt.TokenExpiredError ? 'Token expired' : 'Invalid token'
    return res.status(401).json({ code: 'INVALID_TOKEN', message: msg })
  }
}

// ── Role Authorization ────────────────────────────────────────
export const authorize = (...roles: string[]) =>
  (req: Request, res: Response, next: NextFunction) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ code: 'FORBIDDEN', message: 'Insufficient privileges' })
    }
    next()
  }

// ── Refresh Token ─────────────────────────────────────────────
export function generateTokenPair(userId: string, role: string) {
  const jti = crypto.randomUUID()
  const accessToken = jwt.sign(
    { id: userId, role, jti },
    process.env.JWT_SECRET!,
    { expiresIn: '15m' }
  )
  const refreshToken = jwt.sign(
    { id: userId, role, type: 'refresh' },
    process.env.JWT_REFRESH_SECRET!,
    { expiresIn: '30d' }
  )
  return { accessToken, refreshToken }
}`
    },
    {
      label: "middleware/security.ts",
      code: `import express from 'express'
import helmet from 'helmet'
import cors from 'cors'
import rateLimit from 'express-rate-limit'
import { RedisStore } from 'rate-limit-redis'
import { redis } from '../config/redis'

export function applySecurityMiddleware(app: express.Application) {
  // Security headers
  app.use(helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc:  ["'self'"],
        styleSrc:   ["'self'", "'unsafe-inline'"],
        imgSrc:     ["'self'", 'data:', 'https:'],
      }
    }
  }))

  // CORS — only allow known origins in production
  app.use(cors({
    origin: process.env.ALLOWED_ORIGINS?.split(',') ?? '*',
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
    allowedHeaders: ['Content-Type', 'Authorization'],
    credentials: true
  }))

  // Global rate limit (100 req / 15 min per IP)
  app.use(rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 100,
    standardHeaders: true,
    legacyHeaders: false,
    store: new RedisStore({ sendCommand: (...args: string[]) => redis.call(...args) })
  }))

  // Stricter limit on auth endpoints
  app.use('/api/v1/auth', rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 20,
    message: { code: 'RATE_LIMITED', message: 'Too many auth attempts' }
  }))
}

// ── Input Validation Middleware (Joi) ─────────────────────────
import Joi from 'joi'

export const validate = (schema: Joi.ObjectSchema) =>
  (req: Request, res: Response, next: NextFunction) => {
    const { error, value } = schema.validate(req.body, { abortEarly: false })
    if (error) {
      return res.status(422).json({
        code: 'VALIDATION_ERROR',
        errors: error.details.map(d => ({ field: d.path.join('.'), message: d.message }))
      })
    }
    req.body = value
    next()
  }

// ── Global Error Handler ──────────────────────────────────────
export function globalErrorHandler(
  err: Error, req: Request, res: Response, next: NextFunction
) {
  console.error('[ERROR]', err.stack)
  const status = (err as any).status ?? 500
  res.status(status).json({
    code: 'INTERNAL_ERROR',
    message: process.env.NODE_ENV === 'production' ? 'Internal server error' : err.message
  })
}`
    }
  ],
  jobs: [
    {
      label: "jobs/cron.ts",
      code: `import cron from 'node-cron'
import { prisma } from '../config/db'
import { redis } from '../config/redis'

// ── Recalculate Driver Ratings (02:00 daily) ─────────────────
cron.schedule('0 2 * * *', async () => {
  console.log('[CRON] Recalculating driver ratings...')
  const drivers = await prisma.driver.findMany({ select: { userId: true } })

  for (const driver of drivers) {
    const avg = await prisma.review.aggregate({
      where: { toUserId: driver.userId },
      _avg: { rating: true },
      _count: true
    })
    await prisma.driver.update({
      where: { userId: driver.userId },
      data: {
        rating: avg._avg.rating ?? 0,
        totalTrips: avg._count
      }
    })
  }
  console.log('[CRON] Driver ratings updated')
})

// ── Cleanup Expired OTPs (every 5 min) ───────────────────────
cron.schedule('*/5 * * * *', async () => {
  // Redis TTL handles this automatically; this is a safety sweep
  const keys = await redis.keys('otp:*')
  let pruned = 0
  for (const key of keys) {
    const ttl = await redis.ttl(key)
    if (ttl < 0) { await redis.del(key); pruned++ }
  }
  if (pruned) console.log(\`[CRON] Pruned \${pruned} expired OTPs\`)
})

// ── Daily Revenue Summary (06:00 daily) ──────────────────────
cron.schedule('0 6 * * *', async () => {
  const yesterday = new Date()
  yesterday.setDate(yesterday.getDate() - 1)
  yesterday.setHours(0, 0, 0, 0)

  const revenue = await prisma.payment.aggregate({
    where: { status: 'COMPLETED', createdAt: { gte: yesterday } },
    _sum: { amount: true },
    _count: true
  })
  console.log(\`[CRON] Yesterday revenue: \$\${revenue._sum.amount} (\${revenue._count} tx)\`)
})

// ── Mark Stale Rides as CANCELLED (every 10 min) ─────────────
cron.schedule('*/10 * * * *', async () => {
  const threshold = new Date(Date.now() - 10 * 60 * 1000) // 10 min ago
  const result = await prisma.ride.updateMany({
    where: { status: 'REQUESTED', createdAt: { lt: threshold } },
    data: { status: 'CANCELLED', cancellationReason: 'No driver available', cancelledAt: new Date() }
  })
  if (result.count) console.log(\`[CRON] Auto-cancelled \${result.count} stale rides\`)
})`
    },
    {
      label: "jobs/queue.ts (Bull)",
      code: `import Queue from 'bull'
import { redis } from '../config/redis'
import { sendNotification } from '../services/notification.service'
import { analyzeSentiment } from '../services/ai.service'
import { prisma } from '../config/db'

// ── Notification Queue ────────────────────────────────────────
export const notificationQueue = new Queue('notifications', {
  redis: process.env.REDIS_URL
})

notificationQueue.process(async (job) => {
  const { userId, title, body, data } = job.data
  await sendNotification(userId, title, body, data)
})

// Usage from controllers:
// await notificationQueue.add({ userId, title: 'Ride Confirmed', body: '...' })

// ── Sentiment Analysis Queue ──────────────────────────────────
export const sentimentQueue = new Queue('sentiment', {
  redis: process.env.REDIS_URL
})

sentimentQueue.process(async (job) => {
  const { reviewId, comment } = job.data
  const { sentiment, score } = await analyzeSentiment(comment)
  await prisma.review.update({
    where: { id: reviewId },
    data: { sentiment }
  })
})

// ── Email Report Queue ────────────────────────────────────────
export const emailQueue = new Queue('emails', {
  redis: process.env.REDIS_URL,
  defaultJobOptions: {
    attempts: 3,
    backoff: { type: 'exponential', delay: 5000 }
  }
})

emailQueue.process(async (job) => {
  // SendGrid or SES integration
  console.log('[EMAIL]', job.data)
})`
    }
  ],
  testing: [
    {
      label: "tests/auth.test.ts",
      code: `import request from 'supertest'
import { app } from '../src/app'
import { prisma } from '../src/config/db'
import { redis } from '../src/config/redis'

beforeAll(async () => {
  // Migrate test DB
  await prisma.$executeRaw\`TRUNCATE TABLE "User" CASCADE\`
})
afterAll(async () => {
  await prisma.$disconnect()
  await redis.quit()
})

describe('POST /api/v1/auth/register', () => {
  it('creates user and sends OTP', async () => {
    const res = await request(app)
      .post('/api/v1/auth/register')
      .send({ phone: '+15551234567', password: 'Test1234!', fullName: 'Test User', role: 'USER' })
    expect(res.status).toBe(201)
    expect(res.body).toHaveProperty('userId')
    expect(res.body.message).toBe('OTP sent')
  })

  it('rejects duplicate phone', async () => {
    await request(app).post('/api/v1/auth/register')
      .send({ phone: '+15551234567', password: 'Test1234!', fullName: 'Dup' })
    const res = await request(app).post('/api/v1/auth/register')
      .send({ phone: '+15551234567', password: 'Test1234!', fullName: 'Dup' })
    expect(res.status).toBe(409)
  })

  it('validates required fields', async () => {
    const res = await request(app).post('/api/v1/auth/register').send({})
    expect(res.status).toBe(422)
    expect(res.body.errors.length).toBeGreaterThan(0)
  })
})`
    },
    {
      label: "tests/rides.test.ts",
      code: `import request from 'supertest'
import { app } from '../src/app'
import * as mapsService from '../src/services/googleMaps.service'
import * as aiService from '../src/services/ai.service'

// Mock external services
jest.mock('../src/services/googleMaps.service')
jest.mock('../src/services/ai.service')

const mockMaps = mapsService as jest.Mocked<typeof mapsService>
const mockAI   = aiService   as jest.Mocked<typeof aiService>

let userToken: string

beforeAll(async () => {
  // Login as test user
  const loginRes = await request(app).post('/api/v1/auth/login')
    .send({ identifier: '+15559998888', password: 'Test1234!' })
  userToken = loginRes.body.accessToken
})

describe('POST /api/v1/rides/estimate', () => {
  beforeEach(() => {
    mockMaps.distanceMatrix.mockResolvedValue({
      distance: 12.5, duration: 22,
      text: { distance: '12.5 km', duration: '22 mins' }
    })
    mockAI.predictDynamicSurge.mockResolvedValue({ surge: 1.2, reason: 'Peak hour' })
  })

  it('returns fare estimate', async () => {
    const res = await request(app)
      .post('/api/v1/rides/estimate')
      .set('Authorization', \`Bearer \${userToken}\`)
      .send({ pickup: 'New York, NY', dropoff: 'Boston, MA', rideType: 'car' })
    expect(res.status).toBe(200)
    expect(res.body).toHaveProperty('fare')
    expect(res.body).toHaveProperty('distance')
    expect(res.body).toHaveProperty('duration')
    expect(res.body.fare).toBeGreaterThan(0)
  })

  it('applies surge multiplier from Gemini', async () => {
    const res = await request(app)
      .post('/api/v1/rides/estimate')
      .set('Authorization', \`Bearer \${userToken}\`)
      .send({ pickup: 'New York, NY', dropoff: 'Boston, MA', rideType: 'car' })
    expect(res.body.surgeMultiplier).toBe(1.2)
  })

  it('requires authentication', async () => {
    const res = await request(app)
      .post('/api/v1/rides/estimate')
      .send({ pickup: 'X', dropoff: 'Y', rideType: 'car' })
    expect(res.status).toBe(401)
  })
})`
    }
  ],
  docker: [
    {
      label: "docker-compose.yml",
      code: `version: '3.9'
services:
  api:
    build: .
    ports: ["3000:3000"]
    environment:
      - DATABASE_URL=postgresql://postgres:postgres@postgres:5432/simpleride
      - MONGO_URI=mongodb://mongo:27017/simpleride
      - REDIS_URL=redis://redis:6379
    depends_on: [postgres, mongo, redis]
    volumes: ["./src:/app/src"]  # hot-reload in dev
    command: npm run dev

  postgres:
    image: postgis/postgis:16-3.4
    environment:
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: postgres
      POSTGRES_DB: simpleride
    ports: ["5432:5432"]
    volumes: ["postgres_data:/var/lib/postgresql/data"]

  mongo:
    image: mongo:7
    ports: ["27017:27017"]
    volumes: ["mongo_data:/data/db"]

  redis:
    image: redis:7-alpine
    ports: ["6379:6379"]
    command: redis-server --appendonly yes
    volumes: ["redis_data:/data"]

  pgadmin:
    image: dpage/pgadmin4
    environment:
      PGADMIN_DEFAULT_EMAIL: admin@simpleride.app
      PGADMIN_DEFAULT_PASSWORD: admin
    ports: ["5050:80"]
    depends_on: [postgres]

volumes:
  postgres_data:
  mongo_data:
  redis_data:`
    },
    {
      label: "Dockerfile",
      code: `# ── Build Stage ────────────────────────────────────────────────
FROM node:18-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build          # tsc → dist/

# ── Production Stage ────────────────────────────────────────────
FROM node:18-alpine AS production
RUN apk add --no-cache dumb-init
WORKDIR /app
ENV NODE_ENV=production
COPY package*.json ./
RUN npm ci --omit=dev && npm cache clean --force
COPY --from=builder /app/dist ./dist
COPY --from=builder /app/prisma ./prisma

# Run Prisma migrations at startup
RUN npx prisma generate

EXPOSE 3000
USER node
ENTRYPOINT ["dumb-init", "--"]
CMD ["node", "dist/app.js"]`
    },
    {
      label: ".github/workflows/ci.yml",
      code: `name: CI / CD

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    services:
      postgres:
        image: postgis/postgis:16-3.4
        env:
          POSTGRES_PASSWORD: postgres
          POSTGRES_DB: simpleride_test
        options: >-
          --health-cmd pg_isready
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
      redis:
        image: redis:7-alpine
        options: --health-cmd "redis-cli ping"

    steps:
      - uses: actions/checkout@v4

      - name: Setup Node.js 18
        uses: actions/setup-node@v4
        with: { node-version: '18', cache: 'npm' }

      - run: npm ci
      - run: npm run lint
      - run: npx prisma migrate deploy
        env:
          DATABASE_URL: postgresql://postgres:postgres@localhost:5432/simpleride_test
      - run: npm test -- --coverage
        env:
          DATABASE_URL: postgresql://postgres:postgres@localhost:5432/simpleride_test
          REDIS_URL: redis://localhost:6379
          JWT_SECRET: test_secret_do_not_use

  deploy:
    needs: test
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Deploy to AWS ECS
        run: |
          aws ecs update-service \\
            --cluster simpleride-prod \\
            --service api \\
            --force-new-deployment
        env:
          AWS_ACCESS_KEY_ID: \${{ secrets.AWS_ACCESS_KEY_ID }}
          AWS_SECRET_ACCESS_KEY: \${{ secrets.AWS_SECRET_ACCESS_KEY }}`
    }
  ],
  env: [
    {
      label: ".env.example",
      code: `# ── Application ───────────────────────────────────────────────
NODE_ENV=development
PORT=3000
ALLOWED_ORIGINS=http://localhost:3001,https://simpleride.app

# ── Database ───────────────────────────────────────────────────
DATABASE_URL=postgresql://postgres:postgres@localhost:5432/simpleride
MONGO_URI=mongodb://localhost:27017/simpleride
REDIS_URL=redis://localhost:6379

# ── Authentication ─────────────────────────────────────────────
JWT_SECRET=your_super_secret_jwt_key_min_32_chars
JWT_REFRESH_SECRET=your_refresh_secret_different_from_access

# ── Google Services ────────────────────────────────────────────
GOOGLE_MAPS_API_KEY=AIza...
GCP_PROJECT_ID=your-gcp-project-id
# Place service account JSON (base64 or file path)
GOOGLE_APPLICATION_CREDENTIALS=/path/to/sa.json

# ── Stripe ─────────────────────────────────────────────────────
STRIPE_SECRET_KEY=sk_live_...
STRIPE_WEBHOOK_SECRET=whsec_...

# ── Firebase ───────────────────────────────────────────────────
# Stringify the service account JSON
FIREBASE_SERVICE_ACCOUNT={"type":"service_account","project_id":"..."}

# ── SMS (Twilio) ───────────────────────────────────────────────
TWILIO_ACCOUNT_SID=AC...
TWILIO_AUTH_TOKEN=your_twilio_auth_token
TWILIO_PHONE_NUMBER=+1234567890

# ── AWS (S3 for profile pictures, documents) ───────────────────
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=AKIA...
AWS_SECRET_ACCESS_KEY=...
AWS_S3_BUCKET=simpleride-uploads

# ── Logging ────────────────────────────────────────────────────
LOG_LEVEL=info            # error | warn | info | debug`
    }
  ]
}

const securityChecklist = [
  { label: "Helmet.js security headers", done: true },
  { label: "CORS configured with allowlist", done: true },
  { label: "Rate limiting per IP via Redis", done: true },
  { label: "JWT access + refresh token pair", done: true },
  { label: "Token blacklist on logout", done: true },
  { label: "Password hashing with bcrypt (salt=12)", done: true },
  { label: "Joi input validation on all routes", done: true },
  { label: "Stripe webhook signature verification", done: true },
  { label: "SQL injection prevention (Prisma params)", done: true },
  { label: "Sensitive data excluded from logs", done: true },
  { label: "Non-root Docker user", done: true },
  { label: "Secrets via environment variables only", done: true },
]

export function SecurityPage() {
  const [activeTab, setActiveTab] = useState<TabKey>("middleware")
  const [activeSnippet, setActiveSnippet] = useState(0)

  const handleTabChange = (key: TabKey) => {
    setActiveTab(key)
    setActiveSnippet(0)
  }

  const snippets = CODE[activeTab]

  return (
    <div className="space-y-5">
      {/* Security checklist */}
      <div className="bg-card border border-border rounded-lg p-4">
        <h2 className="text-sm font-semibold text-foreground mb-3">Security Checklist</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-2 gap-x-6">
          {securityChecklist.map((item) => (
            <div key={item.label} className="flex items-center gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-[var(--status-green)] shrink-0" />
              <span className="text-xs text-muted-foreground">{item.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Tab bar */}
      <div className="flex flex-wrap gap-1.5">
        {tabs.map((tab) => (
          <button
            key={tab.key}
            onClick={() => handleTabChange(tab.key)}
            className={cn(
              "flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md border transition-all",
              activeTab === tab.key
                ? "bg-primary/15 text-primary border-primary/30"
                : "bg-card text-muted-foreground border-border hover:text-foreground"
            )}
          >
            <tab.icon className="w-3.5 h-3.5" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Code viewer */}
      <div className="bg-card border border-border rounded-lg overflow-hidden">
        {snippets.length > 1 && (
          <div className="flex border-b border-border overflow-x-auto">
            {snippets.map((s, i) => (
              <button
                key={i}
                onClick={() => setActiveSnippet(i)}
                className={cn(
                  "px-4 py-2.5 text-xs font-mono whitespace-nowrap border-b-2 -mb-px transition-colors",
                  activeSnippet === i
                    ? "border-primary text-primary"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                )}
              >
                {s.label}
              </button>
            ))}
          </div>
        )}
        {snippets.length === 1 && (
          <div className="px-4 py-2.5 border-b border-border">
            <span className="text-xs font-mono text-muted-foreground">{snippets[0].label}</span>
          </div>
        )}
        <div className="overflow-auto max-h-[540px]">
          <div className="code-block border-0 rounded-none p-5">
            <pre className="text-xs leading-relaxed text-foreground/80">
              {snippets[activeSnippet].code}
            </pre>
          </div>
        </div>
      </div>

      {/* Summary table */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {[
          { label: "Background Jobs", items: ["Rate recalculation (02:00 daily)", "OTP cleanup (every 5 min)", "Revenue summary (06:00 daily)", "Stale ride cancellation (10 min)", "Notification queue (Bull)", "Sentiment analysis queue (Bull)"] },
          { label: "Testing Strategy", items: ["Jest unit tests for all services", "Supertest integration tests", "External APIs mocked via jest.mock", "Test DB (separate schema)", "GitHub Actions CI on every PR", "Coverage threshold: 80%"] },
          { label: "Deployment Stack", items: ["Docker multi-stage build", "docker-compose for local dev", "AWS ECS (production)", "AWS RDS (PostgreSQL + PostGIS)", "AWS ElastiCache (Redis)", "GitHub Actions CI/CD pipeline"] },
        ].map((block) => (
          <div key={block.label} className="bg-card border border-border rounded-lg p-4">
            <h3 className="text-xs font-semibold text-foreground mb-3">{block.label}</h3>
            <ul className="space-y-1.5">
              {block.items.map((item) => (
                <li key={item} className="flex items-start gap-2">
                  <span className="w-1 h-1 rounded-full bg-primary mt-1.5 shrink-0" />
                  <span className="text-[11px] text-muted-foreground leading-relaxed">{item}</span>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  )
}
