"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"

type ServiceKey = "maps" | "gemini" | "payment" | "fcm" | "socket"

const serviceItems: { key: ServiceKey; label: string; badge: string; badgeColor: string }[] = [
  { key: "maps", label: "Google Maps", badge: "Places · Directions", badgeColor: "text-[var(--status-amber)] bg-[var(--status-amber)]/10 border-[var(--status-amber)]/25" },
  { key: "gemini", label: "Gemini AI", badge: "Chat · Pricing · Sentiment", badgeColor: "text-[var(--status-red)] bg-[var(--status-red)]/10 border-[var(--status-red)]/25" },
  { key: "payment", label: "Stripe Payments", badge: "PaymentIntent · Webhooks", badgeColor: "text-primary bg-primary/10 border-primary/25" },
  { key: "fcm", label: "Firebase FCM", badge: "Push Notifications", badgeColor: "text-[var(--status-amber)] bg-[var(--status-amber)]/10 border-[var(--status-amber)]/25" },
  { key: "socket", label: "Socket.io", badge: "Real-time · Redis Adapter", badgeColor: "text-[var(--brand-teal)] bg-[var(--brand-teal)]/10 border-[var(--brand-teal)]/25" },
]

const SERVICE_CODE: Record<ServiceKey, { title: string; description: string; snippets: { label: string; code: string }[] }> = {
  maps: {
    title: "Google Maps Service",
    description: "Wraps Places API, Directions API, and Distance Matrix with Redis caching. All calls go server-side to protect the API key.",
    snippets: [
      {
        label: "services/googleMaps.service.ts",
        code: `import axios from 'axios'
import { redis } from '../config/redis'

const BASE = 'https://maps.googleapis.com/maps/api'
const KEY  = process.env.GOOGLE_MAPS_API_KEY

// ── Distance Matrix (fare estimation) ────────────────────────
export async function distanceMatrix(origin: string, destination: string) {
  const cacheKey = \`maps:dist:\${origin}:\${destination}\`
  const cached   = await redis.get(cacheKey)
  if (cached) return JSON.parse(cached)

  const { data } = await axios.get(\`\${BASE}/distancematrix/json\`, {
    params: { origins: origin, destinations: destination, key: KEY }
  })
  const element  = data.rows[0].elements[0]
  const result   = {
    distance: element.distance.value / 1000,   // km
    duration: element.duration.value / 60,     // minutes
    text: {
      distance: element.distance.text,
      duration: element.duration.text
    }
  }
  await redis.setex(cacheKey, 120, JSON.stringify(result))
  return result
}

// ── Directions (polyline for map) ────────────────────────────
export async function getDirections(origin: string, destination: string) {
  const { data } = await axios.get(\`\${BASE}/directions/json\`, {
    params: { origin, destination, key: KEY }
  })
  const route = data.routes[0]
  return {
    polyline: route.overview_polyline.points,
    steps: route.legs[0].steps,
    duration: route.legs[0].duration.text
  }
}

// ── Geocode (address → lat/lng) ───────────────────────────────
export async function geocode(address: string) {
  const { data } = await axios.get(\`\${BASE}/geocode/json\`, {
    params: { address, key: KEY }
  })
  const loc = data.results[0].geometry.location
  return { lat: loc.lat, lng: loc.lng }
}

// ── Reverse Geocode ──────────────────────────────────────────
export async function reverseGeocode(lat: number, lng: number) {
  const { data } = await axios.get(\`\${BASE}/geocode/json\`, {
    params: { latlng: \`\${lat},\${lng}\`, key: KEY }
  })
  return data.results[0].formatted_address as string
}

// ── Place Autocomplete ────────────────────────────────────────
export async function placeAutocomplete(input: string, sessionToken: string) {
  const { data } = await axios.get(\`\${BASE}/place/autocomplete/json\`, {
    params: { input, sessiontoken: sessionToken, key: KEY }
  })
  return data.predictions.map((p: any) => ({
    placeId: p.place_id,
    description: p.description
  }))
}`
      }
    ]
  },
  gemini: {
    title: "Gemini AI Service",
    description: "Google Cloud AI Platform integration using Application Default Credentials. Logs all interactions to MongoDB for model improvement.",
    snippets: [
      {
        label: "services/ai.service.ts",
        code: `import { GoogleAuth } from 'google-auth-library'
import { AIInteraction } from '../models/AIInteraction'

const auth      = new GoogleAuth({ scopes: 'https://www.googleapis.com/auth/cloud-platform' })
const PROJECT   = process.env.GCP_PROJECT_ID
const LOCATION  = 'us-central1'
const GEMINI_URL = (model: string) =>
  \`https://\${LOCATION}-aiplatform.googleapis.com/v1/projects/\${PROJECT}/\` +
  \`locations/\${LOCATION}/publishers/google/models/\${model}:generateContent\`

async function callGemini(model: string, prompt: string, temperature = 0.2) {
  const client   = await auth.getClient()
  const { data } = await client.request({
    url: GEMINI_URL(model),
    method: 'POST',
    data: {
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      generationConfig: { temperature, maxOutputTokens: 512 }
    }
  })
  return (data as any).candidates[0].content.parts[0].text as string
}

// ── Chatbot ─────────────────────────────────────────────────
export async function getChatbotResponse(userId: string, message: string) {
  const prompt = \`You are SIMPLE RIDE's helpful assistant. Answer concisely.
User: \${message}
Assistant:\`
  const start    = Date.now()
  const response = await callGemini('gemini-pro', prompt, 0.4)
  await AIInteraction.create({
    userId, type: 'chatbot',
    request: { message },
    response: { text: response },
    latencyMs: Date.now() - start
  })
  return response
}

// ── Dynamic Pricing ──────────────────────────────────────────
export async function predictDynamicSurge(lat: number, lng: number, time: Date) {
  const prompt = \`Given location (\${lat}, \${lng}) at \${time.toISOString()},
predict demand surge multiplier (1.0–3.0) for a ride-hailing service.
Return JSON: { "surge": number, "reason": string }\`
  const raw    = await callGemini('gemini-pro', prompt, 0.1)
  return JSON.parse(raw) as { surge: number; reason: string }
}

// ── Sentiment Analysis ────────────────────────────────────────
export async function analyzeSentiment(review: string) {
  const prompt = \`Classify this review as "positive", "neutral", or "negative".
Return JSON: { "sentiment": string, "score": number (0–1) }
Review: "\${review}"\`
  const raw = await callGemini('gemini-pro', prompt, 0.0)
  return JSON.parse(raw) as { sentiment: string; score: number }
}

// ── Restaurant Recommendations ───────────────────────────────
export async function getRecommendations(userId: string, history: string[]) {
  const prompt = \`Based on past orders: [\${history.join(', ')}],
suggest 3 cuisine types the user might enjoy.
Return JSON: { "suggestions": string[] }\`
  const raw = await callGemini('gemini-pro', prompt, 0.3)
  return JSON.parse(raw) as { suggestions: string[] }
}`
      }
    ]
  },
  payment: {
    title: "Stripe Payment Service",
    description: "Handles PaymentIntent creation for card payments, webhook signature verification, and automatic refund flows on cancellations.",
    snippets: [
      {
        label: "services/payment.service.ts",
        code: `import Stripe from 'stripe'
import { prisma } from '../config/db'
import { sendNotification } from './notification.service'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-04-10'
})

// ── Create Payment Intent ────────────────────────────────────
export async function createPaymentIntent(
  amount: number,   // in cents
  currency: string,
  metadata: { userId: string; rideId?: string; orderId?: string }
) {
  const intent = await stripe.paymentIntents.create({
    amount,
    currency,
    automatic_payment_methods: { enabled: true },
    metadata
  })
  await prisma.payment.create({
    data: {
      transactionId: intent.id,
      userId: metadata.userId,
      rideId: metadata.rideId,
      orderId: metadata.orderId,
      amount: amount / 100,
      currency,
      method: 'CARD',
      status: 'PENDING'
    }
  })
  return { clientSecret: intent.client_secret }
}

// ── Webhook Handler ───────────────────────────────────────────
export async function handleStripeWebhook(rawBody: Buffer, sig: string) {
  const event = stripe.webhooks.constructEvent(
    rawBody, sig, process.env.STRIPE_WEBHOOK_SECRET!
  )
  switch (event.type) {
    case 'payment_intent.succeeded': {
      const intent = event.data.object as Stripe.PaymentIntent
      await prisma.payment.update({
        where: { transactionId: intent.id },
        data: { status: 'COMPLETED', gatewayResponse: intent }
      })
      await sendNotification(intent.metadata.userId, 'Payment Confirmed',
        \`Your payment of \${(intent.amount / 100).toFixed(2)} \${intent.currency.toUpperCase()} was successful.\`)
      break
    }
    case 'payment_intent.payment_failed': {
      const intent = event.data.object as Stripe.PaymentIntent
      await prisma.payment.update({
        where: { transactionId: intent.id },
        data: { status: 'FAILED' }
      })
      break
    }
  }
}

// ── Refund ────────────────────────────────────────────────────
export async function refundPayment(transactionId: string, reason?: string) {
  const refund = await stripe.refunds.create({
    payment_intent: transactionId,
    reason: 'requested_by_customer'
  })
  await prisma.payment.update({
    where: { transactionId },
    data: { status: 'REFUNDED', gatewayResponse: refund }
  })
  return refund
}`
      }
    ]
  },
  fcm: {
    title: "Firebase Cloud Messaging",
    description: "Sends targeted push notifications to iOS and Android devices using stored FCM tokens. Handles multicast for multiple devices per user.",
    snippets: [
      {
        label: "services/notification.service.ts",
        code: `import admin from 'firebase-admin'
import { prisma } from '../config/db'

// Initialise once at app startup
if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert(
      JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT!)
    )
  })
}

export async function sendNotification(
  userId: string,
  title: string,
  body: string,
  data?: Record<string, string>
) {
  const user = await prisma.user.findUnique({ where: { id: userId } })
  if (!user) return
  const tokens = (user.deviceTokens as string[] | null) ?? []
  if (!tokens.length) return

  const result = await admin.messaging().sendEachForMulticast({
    tokens,
    notification: { title, body },
    data,
    android: { priority: 'high' },
    apns:    { payload: { aps: { sound: 'default' } } }
  })

  // Prune stale tokens
  const staleTokens: string[] = []
  result.responses.forEach((r, i) => {
    if (!r.success && r.error?.code === 'messaging/registration-token-not-registered') {
      staleTokens.push(tokens[i])
    }
  })
  if (staleTokens.length) {
    await prisma.user.update({
      where: { id: userId },
      data: {
        deviceTokens: tokens.filter(t => !staleTokens.includes(t))
      }
    })
  }
  return result
}

// Convenience wrappers
export const notifyRideAccepted  = (userId: string, driverName: string) =>
  sendNotification(userId, 'Ride Accepted!',
    \`\${driverName} is on the way.\`, { type: 'ride_accepted' })

export const notifyOrderReady    = (userId: string) =>
  sendNotification(userId, 'Order Ready!',
    'Your order has been picked up and is on its way.', { type: 'order_picked_up' })`
      }
    ]
  },
  socket: {
    title: "Socket.io Real-time Layer",
    description: "JWT-authenticated WebSocket server with Redis pub/sub adapter for multi-instance scaling. Emits and receives 12 distinct event types.",
    snippets: [
      {
        label: "sockets/index.ts",
        code: `import { Server, Socket } from 'socket.io'
import { createAdapter } from '@socket.io/redis-adapter'
import Redis from 'ioredis'
import { verifyToken } from '../utils/jwt'
import { LocationLog } from '../models/LocationLog'

const pubClient = new Redis(process.env.REDIS_URL!)
const subClient = pubClient.duplicate()

export function setupSocket(io: Server) {
  // Scale across multiple Node processes / pods
  io.adapter(createAdapter(pubClient, subClient))

  // ── JWT Auth Middleware ───────────────────────────────────
  io.use((socket: Socket, next) => {
    const token = socket.handshake.auth?.token as string
    if (!token) return next(new Error('AUTHENTICATION_REQUIRED'))
    try {
      socket.data.user = verifyToken(token)
      next()
    } catch {
      next(new Error('INVALID_TOKEN'))
    }
  })

  io.on('connection', (socket: Socket) => {
    const { id: userId, role } = socket.data.user
    socket.join(\`user:\${userId}\`)
    console.log(\`[WS] \${role} \${userId} connected\`)

    // ── Subscribe to Ride Room ────────────────────────────
    socket.on('join_ride', (rideId: string) => {
      socket.join(\`ride:\${rideId}\`)
    })

    socket.on('leave_ride', (rideId: string) => {
      socket.leave(\`ride:\${rideId}\`)
    })

    // ── Driver Location Broadcast ─────────────────────────
    socket.on('driver_location', async (data: {
      rideId: string; lat: number; lng: number; heading?: number
    }) => {
      // Persist to MongoDB
      await LocationLog.create({
        driverId: userId, rideId: data.rideId,
        lat: data.lat, lng: data.lng, heading: data.heading
      })
      // Broadcast to all room members (user + admin)
      socket.to(\`ride:\${data.rideId}\`).emit('driver_location', {
        lat: data.lat, lng: data.lng, heading: data.heading, ts: Date.now()
      })
    })

    // ── Chat Message ──────────────────────────────────────
    socket.on('chat_message', async (msg: {
      rideId?: string; orderId?: string; receiverId: string; text: string
    }) => {
      io.to(\`user:\${msg.receiverId}\`).emit('chat_message', {
        senderId: userId, text: msg.text, ts: Date.now()
      })
    })

    socket.on('disconnect', () => {
      console.log(\`[WS] \${userId} disconnected\`)
    })
  })
}

// ── Server-side Emitters (called from controllers) ────────────
export function emitRideStatus(io: Server, rideId: string, status: string) {
  io.to(\`ride:\${rideId}\`).emit('ride_status', { rideId, status, ts: Date.now() })
}

export function emitNewRideRequest(io: Server, driverId: string, payload: object) {
  io.to(\`user:\${driverId}\`).emit('new_ride_request', payload)
}

export function emitOrderStatus(io: Server, userId: string, orderId: string, status: string) {
  io.to(\`user:\${userId}\`).emit('order_status', { orderId, status, ts: Date.now() })
}`
      },
      {
        label: "Socket.io Events Reference",
        code: `// ── Client → Server ────────────────────────────────────────
socket.emit('join_ride',        rideId)
socket.emit('leave_ride',       rideId)
socket.emit('driver_location',  { rideId, lat, lng, heading })
socket.emit('chat_message',     { rideId?, orderId?, receiverId, text })

// ── Server → Client ────────────────────────────────────────
socket.on('driver_location',    ({ lat, lng, heading, ts }) => { ... })
socket.on('ride_status',        ({ rideId, status, ts }) => { ... })
socket.on('order_status',       ({ orderId, status, ts }) => { ... })
socket.on('new_ride_request',   (payload) => { ... })   // DRIVER only
socket.on('new_order_assignment', (payload) => { ... }) // DRIVER only
socket.on('chat_message',       ({ senderId, text, ts }) => { ... })
socket.on('ride_cancelled',     ({ rideId, reason }) => { ... })
socket.on('driver_arrived',     ({ rideId }) => { ... })`
      }
    ]
  }
}

export function ServicesPage() {
  const [activeService, setActiveService] = useState<ServiceKey>("maps")
  const [activeSnippet, setActiveSnippet] = useState(0)
  const service = SERVICE_CODE[activeService]

  const handleServiceChange = (key: ServiceKey) => {
    setActiveService(key)
    setActiveSnippet(0)
  }

  return (
    <div className="space-y-5">
      {/* Service selector */}
      <div className="flex flex-wrap gap-2">
        {serviceItems.map((s) => (
          <button
            key={s.key}
            onClick={() => handleServiceChange(s.key)}
            className={cn(
              "flex items-center gap-2 px-3 py-1.5 rounded-md border text-xs font-medium transition-all",
              activeService === s.key
                ? "bg-primary/15 text-primary border-primary/30"
                : "bg-card text-muted-foreground border-border hover:text-foreground hover:border-border/70"
            )}
          >
            {s.label}
            <span className={cn("text-[10px] font-mono px-1 py-0.5 rounded border", s.badgeColor)}>
              {s.badge}
            </span>
          </button>
        ))}
      </div>

      {/* Service header */}
      <div className="bg-card border border-border rounded-lg p-4">
        <h2 className="text-sm font-semibold text-foreground mb-1">{service.title}</h2>
        <p className="text-xs text-muted-foreground leading-relaxed">{service.description}</p>
      </div>

      {/* Code viewer */}
      <div className="bg-card border border-border rounded-lg overflow-hidden">
        {service.snippets.length > 1 && (
          <div className="flex border-b border-border overflow-x-auto">
            {service.snippets.map((s, i) => (
              <button
                key={i}
                onClick={() => setActiveSnippet(i)}
                className={cn(
                  "px-4 py-2.5 text-xs font-mono whitespace-nowrap border-b-2 -mb-px transition-colors",
                  activeSnippet === i
                    ? "border-primary text-primary"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                )}
              >
                {s.label}
              </button>
            ))}
          </div>
        )}
        {service.snippets.length === 1 && (
          <div className="flex items-center px-4 py-2.5 border-b border-border">
            <span className="text-xs font-mono text-muted-foreground">{service.snippets[0].label}</span>
          </div>
        )}
        <div className="overflow-auto max-h-[520px]">
          <div className="code-block border-0 rounded-none p-5">
            <pre className="text-xs leading-relaxed text-foreground/80">
              {service.snippets[activeSnippet].code}
            </pre>
          </div>
        </div>
      </div>

      {/* WS Event matrix for socket tab */}
      {activeService === "socket" && (
        <div className="bg-card border border-border rounded-lg overflow-hidden">
          <div className="px-4 py-3 border-b border-border">
            <h3 className="text-sm font-semibold text-foreground">WebSocket Event Matrix</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left px-4 py-2.5 text-muted-foreground font-medium">Event</th>
                  <th className="text-left px-4 py-2.5 text-muted-foreground font-medium">Direction</th>
                  <th className="text-left px-4 py-2.5 text-muted-foreground font-medium">Audience</th>
                  <th className="text-left px-4 py-2.5 text-muted-foreground font-medium">Payload</th>
                </tr>
              </thead>
              <tbody>
                {[
                  { event: "join_ride", dir: "C → S", audience: "User / Driver", payload: "rideId: string" },
                  { event: "driver_location", dir: "C → S", audience: "Driver", payload: "{ rideId, lat, lng, heading }" },
                  { event: "driver_location", dir: "S → C", audience: "User", payload: "{ lat, lng, heading, ts }" },
                  { event: "ride_status", dir: "S → C", audience: "User + Driver", payload: "{ rideId, status, ts }" },
                  { event: "order_status", dir: "S → C", audience: "User", payload: "{ orderId, status, ts }" },
                  { event: "new_ride_request", dir: "S → C", audience: "Driver", payload: "{ rideId, pickup, dropoff, fare }" },
                  { event: "new_order_assignment", dir: "S → C", audience: "Driver", payload: "{ orderId, restaurant, address }" },
                  { event: "chat_message", dir: "C → S & S → C", audience: "Both", payload: "{ rideId?, senderId, text, ts }" },
                  { event: "ride_cancelled", dir: "S → C", audience: "User + Driver", payload: "{ rideId, reason }" },
                  { event: "driver_arrived", dir: "S → C", audience: "User", payload: "{ rideId }" },
                ].map((row) => (
                  <tr key={row.event + row.dir} className="border-b border-border/50 hover:bg-secondary/30 transition-colors">
                    <td className="px-4 py-2.5 font-mono text-[var(--brand-teal)]">{row.event}</td>
                    <td className="px-4 py-2.5">
                      <span className={cn("text-[10px] font-mono px-1.5 py-0.5 rounded border",
                        row.dir.startsWith("C → S") ? "text-primary border-primary/25 bg-primary/10" :
                        row.dir.startsWith("S → C") ? "text-[var(--status-green)] border-[var(--status-green)]/25 bg-[var(--status-green)]/10" :
                        "text-[var(--status-amber)] border-[var(--status-amber)]/25 bg-[var(--status-amber)]/10"
                      )}>
                        {row.dir}
                      </span>
                    </td>
                    <td className="px-4 py-2.5 text-muted-foreground">{row.audience}</td>
                    <td className="px-4 py-2.5 font-mono text-muted-foreground">{row.payload}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}
