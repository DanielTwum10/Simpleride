"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"

const prismaSchema = `// prisma/schema.prisma
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

model User {
  id            String    @id @default(uuid())
  phone         String?   @unique
  email         String?   @unique
  passwordHash  String?
  fullName      String
  profilePic    String?
  role          Role      @default(USER)
  isVerified    Boolean   @default(false)
  deviceTokens  Json?     // FCM token array
  createdAt     DateTime  @default(now())
  updatedAt     DateTime  @updatedAt

  addresses       Address[]
  ridesAsUser     Ride[]    @relation("UserRides")
  ridesAsDriver   Ride[]    @relation("DriverRides")
  orders          Order[]
  payments        Payment[]
  reviewsGiven    Review[]  @relation("ReviewFromUser")
  reviewsReceived Review[]  @relation("ReviewToUser")
}

model Driver {
  id              String      @id @default(uuid())
  userId          String      @unique
  user            User        @relation(fields: [userId], references: [id])
  licenseNumber   String
  licenseExpiry   DateTime
  vehicleType     VehicleType
  vehicleModel    String
  vehiclePlate    String
  isVerified      Boolean     @default(false)
  // PostGIS — stored as separate floats; spatial index via raw SQL migration
  currentLat      Float?
  currentLng      Float?
  isOnline        Boolean     @default(false)
  rating          Float       @default(0)
  totalTrips      Int         @default(0)
  totalEarnings   Float       @default(0)
  createdAt       DateTime    @default(now())
  updatedAt       DateTime    @updatedAt
}

model Restaurant {
  id             String     @id @default(uuid())
  name           String
  description    String?
  address        String
  lat            Float
  lng            Float
  cuisineTypes   String[]
  priceRange     Int        // 1–4
  rating         Float      @default(0)
  commissionRate Float      @default(0.15)
  isActive       Boolean    @default(true)
  contactPhone   String
  openingHours   Json?
  createdAt      DateTime   @default(now())
  updatedAt      DateTime   @updatedAt

  menuItems  MenuItem[]
  orders     Order[]
  reviews    Review[]
}

model MenuItem {
  id                   String     @id @default(uuid())
  restaurantId         String
  restaurant           Restaurant @relation(fields: [restaurantId], references: [id])
  name                 String
  description          String?
  price                Float
  category             String
  imageUrl             String?
  customizationOptions Json?
  isAvailable          Boolean    @default(true)
  preparationTime      Int?       // minutes
  createdAt            DateTime   @default(now())
  updatedAt            DateTime   @updatedAt
}

model Ride {
  id               String        @id @default(uuid())
  userId           String
  user             User          @relation("UserRides", fields: [userId], references: [id])
  driverId         String?
  driver           User?         @relation("DriverRides", fields: [driverId], references: [id])
  rideType         RideType
  pickupLat        Float
  pickupLng        Float
  dropoffLat       Float
  dropoffLng       Float
  pickupAddress    String
  dropoffAddress   String
  fare             Float
  distance         Float         // km
  duration         Int           // minutes
  status           RideStatus    @default(REQUESTED)
  paymentMethod    PaymentMethod
  paymentStatus    PaymentStatus @default(PENDING)
  createdAt        DateTime      @default(now())
  startedAt        DateTime?
  completedAt      DateTime?
  cancelledAt      DateTime?
  cancellationReason String?

  payment  Payment?
  review   Review?
}

model Order {
  id                String      @id @default(uuid())
  userId            String
  user              User        @relation(fields: [userId], references: [id])
  driverId          String?
  restaurantId      String
  restaurant        Restaurant  @relation(fields: [restaurantId], references: [id])
  items             Json        // [{ menuItemId, name, price, quantity, customization }]
  subtotal          Float
  deliveryFee       Float
  tax               Float
  totalAmount       Float
  deliveryAddress   String
  deliveryLat       Float
  deliveryLng       Float
  status            OrderStatus @default(PENDING)
  estimatedPrepTime Int?
  createdAt         DateTime    @default(now())
  confirmedAt       DateTime?
  pickedUpAt        DateTime?
  deliveredAt       DateTime?
  cancelledAt       DateTime?

  payment  Payment?
  review   Review?
}

model Payment {
  id              String        @id @default(uuid())
  transactionId   String        @unique
  userId          String
  user            User          @relation(fields: [userId], references: [id])
  rideId          String?       @unique
  orderId         String?       @unique
  amount          Float
  currency        String        @default("USD")
  method          PaymentMethod
  status          PaymentStatus @default(PENDING)
  gatewayResponse Json?
  createdAt       DateTime      @default(now())

  ride   Ride?   @relation(fields: [rideId], references: [id])
  order  Order?  @relation(fields: [orderId], references: [id])
}

model Review {
  id             String      @id @default(uuid())
  fromUserId     String
  fromUser       User        @relation("ReviewFromUser", fields: [fromUserId], references: [id])
  toUserId       String?
  toRestaurantId String?
  toUser         User?       @relation("ReviewToUser", fields: [toUserId], references: [id])
  toRestaurant   Restaurant? @relation(fields: [toRestaurantId], references: [id])
  rideId         String?     @unique
  orderId        String?     @unique
  rating         Int         // 1–5
  comment        String?
  sentiment      String?     // Gemini AI analysed: positive | neutral | negative
  createdAt      DateTime    @default(now())

  ride   Ride?   @relation(fields: [rideId], references: [id])
  order  Order?  @relation(fields: [orderId], references: [id])
}

// Enums
enum Role          { USER DRIVER ADMIN }
enum VehicleType   { MOTORCYCLE CAR }
enum RideType      { MOTORCYCLE CAR }
enum RideStatus    { REQUESTED ACCEPTED STARTED COMPLETED CANCELLED }
enum OrderStatus   { PENDING CONFIRMED PREPARING READY_PICKUP PICKED_UP DELIVERED CANCELLED }
enum PaymentMethod { CARD CASH WALLET }
enum PaymentStatus { PENDING COMPLETED FAILED REFUNDED }`

const mongoSchemas = `// models/ChatMessage.ts
import mongoose from 'mongoose'

const chatMessageSchema = new mongoose.Schema({
  rideId:     { type: String, index: true },
  orderId:    { type: String, index: true },
  senderId:   { type: String, required: true },
  receiverId: { type: String, required: true },
  message:    { type: String, required: true },
  timestamp:  { type: Date, default: Date.now },
  read:       { type: Boolean, default: false }
})
export const ChatMessage = mongoose.model('ChatMessage', chatMessageSchema)

// ─────────────────────────────────────────────────────────────

// models/LocationLog.ts  — driver GPS history
const locationLogSchema = new mongoose.Schema({
  driverId:  { type: String, required: true, index: true },
  rideId:    { type: String },
  lat:       { type: Number, required: true },
  lng:       { type: Number, required: true },
  speed:     { type: Number },        // km/h
  heading:   { type: Number },        // 0–360°
  timestamp: { type: Date, default: Date.now }
})
// 2dsphere index for geo-queries if needed
locationLogSchema.index({ driverId: 1, timestamp: -1 })
export const LocationLog = mongoose.model('LocationLog', locationLogSchema)

// ─────────────────────────────────────────────────────────────

// models/AIInteraction.ts  — Gemini API logs
const aiInteractionSchema = new mongoose.Schema({
  userId:    { type: String, index: true },
  sessionId: { type: String },
  type:      {
    type: String,
    enum: ['chatbot', 'recommendation', 'pricing', 'sentiment', 'routing']
  },
  request:   { type: mongoose.Schema.Types.Mixed },
  response:  { type: mongoose.Schema.Types.Mixed },
  latencyMs: { type: Number },
  model:     { type: String, default: 'gemini-pro' },
  timestamp: { type: Date, default: Date.now }
})
export const AIInteraction = mongoose.model('AIInteraction', aiInteractionSchema)`

const spatialSql = `-- PostGIS spatial index on Driver location
CREATE EXTENSION IF NOT EXISTS postgis;

ALTER TABLE "Driver"
  ADD COLUMN location geography(POINT, 4326)
  GENERATED ALWAYS AS (
    CASE WHEN "currentLat" IS NOT NULL
      THEN ST_SetSRID(ST_MakePoint("currentLng", "currentLat"), 4326)::geography
    END
  ) STORED;

CREATE INDEX idx_driver_location ON "Driver" USING GIST (location);

-- Find drivers within 5km
SELECT d.*, u."fullName", u."profilePic",
  ST_Distance(d.location,
    ST_SetSRID(ST_MakePoint($1, $2), 4326)::geography
  ) AS distance_meters
FROM "Driver" d
JOIN "User" u ON u.id = d."userId"
WHERE d."isOnline" = true
  AND d."isVerified" = true
  AND ST_DWithin(
    d.location,
    ST_SetSRID(ST_MakePoint($1, $2), 4326)::geography,
    5000   -- 5,000 meters
  )
ORDER BY distance_meters
LIMIT 10;

-- Nearby restaurants
SELECT r.*,
  ST_Distance(
    ST_SetSRID(ST_MakePoint(r.lng, r.lat), 4326)::geography,
    ST_SetSRID(ST_MakePoint($1, $2), 4326)::geography
  ) AS distance_meters
FROM "Restaurant" r
WHERE r."isActive" = true
  AND ST_DWithin(
    ST_SetSRID(ST_MakePoint(r.lng, r.lat), 4326)::geography,
    ST_SetSRID(ST_MakePoint($1, $2), 4326)::geography,
    $3     -- configurable radius in meters
  )
ORDER BY r.rating DESC, distance_meters
LIMIT 20;`

const redisPatterns = `// config/redis.ts
import Redis from 'ioredis'

export const redis = new Redis(process.env.REDIS_URL)

// ── OTP Storage ──────────────────────────────────────────────
// TTL: 5 minutes
await redis.setex(\`otp:\${phone}\`, 300, otp)
const stored = await redis.get(\`otp:\${phone}\`)

// ── Token Blacklist (logout) ──────────────────────────────────
// TTL matches token expiry
await redis.setex(\`blacklist:\${jti}\`, 900, '1')
const isBlacklisted = await redis.exists(\`blacklist:\${jti}\`)

// ── Ride Estimate Cache ───────────────────────────────────────
// TTL: 2 minutes (price may shift)
const cacheKey = \`estimate:\${pickup}:\${dropoff}:\${rideType}\`
await redis.setex(cacheKey, 120, JSON.stringify(estimate))

// ── Restaurant List Cache ─────────────────────────────────────
// TTL: 5 minutes
await redis.setex(\`restaurants:\${lat}:\${lng}:\${radius}\`, 300, JSON.stringify(list))

// ── Rate Limiting ─────────────────────────────────────────────
// express-rate-limit with Redis store
import { RedisStore } from 'rate-limit-redis'
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 min
  max: 100,
  standardHeaders: true,
  store: new RedisStore({ sendCommand: (...args) => redis.call(...args) })
})

// ── Socket.io Scaling ─────────────────────────────────────────
import { createAdapter } from '@socket.io/redis-adapter'
const pubClient = new Redis(process.env.REDIS_URL)
const subClient = pubClient.duplicate()
io.adapter(createAdapter(pubClient, subClient))`

type TabKey = "prisma" | "mongo" | "postgis" | "redis"

const tabs: { key: TabKey; label: string; lang: string }[] = [
  { key: "prisma", label: "Prisma Schema", lang: "prisma" },
  { key: "mongo", label: "MongoDB Models", lang: "typescript" },
  { key: "postgis", label: "PostGIS SQL", lang: "sql" },
  { key: "redis", label: "Redis Patterns", lang: "typescript" },
]

const CONTENT: Record<TabKey, string> = {
  prisma: prismaSchema,
  mongo: mongoSchemas,
  postgis: spatialSql,
  redis: redisPatterns,
}

const architectureNodes = [
  { label: "Mobile / Web Client", color: "border-muted-foreground/40 text-muted-foreground", sub: "React Native / Next.js" },
  { label: "API Gateway", color: "border-primary/40 text-primary", sub: "Express + Helmet + CORS" },
  { label: "Auth Layer", color: "border-[var(--status-green)]/40 text-[var(--status-green)]", sub: "JWT · OAuth2 · Passport" },
  { label: "Business Logic", color: "border-[var(--brand-teal)]/40 text-[var(--brand-teal)]", sub: "Services · Controllers" },
  { label: "PostgreSQL + PostGIS", color: "border-primary/40 text-primary", sub: "Prisma ORM · Spatial Queries" },
  { label: "MongoDB", color: "border-[var(--status-green)]/40 text-[var(--status-green)]", sub: "Chat · Logs · AI Data" },
  { label: "Redis", color: "border-[var(--status-red)]/40 text-[var(--status-red)]", sub: "Cache · PubSub · Sessions" },
  { label: "Socket.io", color: "border-[var(--status-amber)]/40 text-[var(--status-amber)]", sub: "Real-time · Redis Adapter" },
  { label: "Google Maps API", color: "border-[var(--brand-teal)]/40 text-[var(--brand-teal)]", sub: "Places · Directions · Matrix" },
  { label: "Gemini AI", color: "border-[var(--status-red)]/40 text-[var(--status-red)]", sub: "Chat · Pricing · Sentiment" },
  { label: "Stripe / Razorpay", color: "border-primary/40 text-primary", sub: "PaymentIntent · Webhooks" },
  { label: "Firebase FCM", color: "border-[var(--status-amber)]/40 text-[var(--status-amber)]", sub: "Push Notifications" },
]

export function ArchitecturePage() {
  const [activeTab, setActiveTab] = useState<TabKey>("prisma")

  return (
    <div className="space-y-6">
      {/* System architecture diagram */}
      <div className="bg-card border border-border rounded-lg p-5">
        <h2 className="text-sm font-semibold text-foreground mb-1">System Architecture</h2>
        <p className="text-xs text-muted-foreground mb-4">Component overview and data flow</p>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2.5">
          {architectureNodes.map((node) => (
            <div
              key={node.label}
              className={cn("bg-secondary border rounded-md px-3 py-2.5 text-center transition-colors hover:bg-muted", node.color)}
            >
              <p className="text-xs font-semibold">{node.label}</p>
              <p className="text-[10px] text-muted-foreground mt-0.5">{node.sub}</p>
            </div>
          ))}
        </div>

        {/* Flow arrows */}
        <div className="mt-4 pt-4 border-t border-border">
          <p className="text-[11px] text-muted-foreground font-semibold uppercase tracking-wide mb-3">Request Flow</p>
          <div className="flex flex-wrap items-center gap-1.5 text-[11px] font-mono">
            {[
              { label: "Client", color: "text-muted-foreground" },
              { label: "→", color: "text-muted-foreground/40" },
              { label: "Express Router", color: "text-primary" },
              { label: "→", color: "text-muted-foreground/40" },
              { label: "Auth Middleware", color: "text-[var(--status-green)]" },
              { label: "→", color: "text-muted-foreground/40" },
              { label: "Validate (Joi)", color: "text-[var(--status-amber)]" },
              { label: "→", color: "text-muted-foreground/40" },
              { label: "Controller", color: "text-[var(--brand-teal)]" },
              { label: "→", color: "text-muted-foreground/40" },
              { label: "Service", color: "text-[var(--brand-teal)]" },
              { label: "→", color: "text-muted-foreground/40" },
              { label: "DB / Cache / AI", color: "text-primary" },
              { label: "→", color: "text-muted-foreground/40" },
              { label: "Response", color: "text-muted-foreground" },
            ].map((item, i) => (
              <span key={i} className={item.color}>{item.label}</span>
            ))}
          </div>
        </div>
      </div>

      {/* Schema viewer */}
      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <div className="flex items-center border-b border-border overflow-x-auto">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={cn(
                "px-4 py-3 text-xs font-medium whitespace-nowrap transition-colors border-b-2 -mb-px",
                activeTab === tab.key
                  ? "border-primary text-primary"
                  : "border-transparent text-muted-foreground hover:text-foreground"
              )}
            >
              {tab.label}
            </button>
          ))}
          <div className="ml-auto px-4">
            <span className="text-[10px] font-mono text-muted-foreground/50">
              {tabs.find(t => t.key === activeTab)?.lang}
            </span>
          </div>
        </div>
        <div className="overflow-auto max-h-[600px]">
          <div className="code-block border-0 rounded-none p-5">
            <pre className="text-xs leading-relaxed text-foreground/80">{CONTENT[activeTab]}</pre>
          </div>
        </div>
      </div>

      {/* Database summary table */}
      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <div className="px-4 py-3 border-b border-border">
          <h2 className="text-sm font-semibold text-foreground">Database Models Summary</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left px-4 py-2.5 text-muted-foreground font-medium">Model</th>
                <th className="text-left px-4 py-2.5 text-muted-foreground font-medium">Database</th>
                <th className="text-left px-4 py-2.5 text-muted-foreground font-medium">Key Fields</th>
                <th className="text-left px-4 py-2.5 text-muted-foreground font-medium">Relations</th>
              </tr>
            </thead>
            <tbody>
              {[
                { model: "User", db: "PostgreSQL", fields: "id, phone, email, role, isVerified, deviceTokens", rel: "Rides, Orders, Reviews, Payments" },
                { model: "Driver", db: "PostgreSQL", fields: "userId, vehicleType, currentLat/Lng, isOnline, rating", rel: "User (1:1)" },
                { model: "Restaurant", db: "PostgreSQL", fields: "lat, lng, cuisineTypes[], rating, commissionRate", rel: "MenuItems, Orders, Reviews" },
                { model: "MenuItem", db: "PostgreSQL", fields: "restaurantId, price, category, customizationOptions", rel: "Restaurant" },
                { model: "Ride", db: "PostgreSQL", fields: "userId, driverId, pickupLat/Lng, fare, status", rel: "User, Payment, Review" },
                { model: "Order", db: "PostgreSQL", fields: "userId, restaurantId, items (JSON), totalAmount, status", rel: "User, Restaurant, Payment, Review" },
                { model: "Payment", db: "PostgreSQL", fields: "transactionId, amount, method, status, gatewayResponse", rel: "User, Ride?, Order?" },
                { model: "Review", db: "PostgreSQL", fields: "rating (1–5), comment, sentiment (AI)", rel: "User, Restaurant, Ride?, Order?" },
                { model: "ChatMessage", db: "MongoDB", fields: "rideId, senderId, message, read, timestamp", rel: "— (document)" },
                { model: "LocationLog", db: "MongoDB", fields: "driverId, lat, lng, speed, heading, timestamp", rel: "— (document)" },
                { model: "AIInteraction", db: "MongoDB", fields: "userId, type, request, response, latencyMs", rel: "— (document)" },
              ].map((row) => (
                <tr key={row.model} className="border-b border-border/50 hover:bg-secondary/30 transition-colors">
                  <td className="px-4 py-2.5 font-mono font-semibold text-foreground">{row.model}</td>
                  <td className="px-4 py-2.5">
                    <span className={cn("text-[10px] font-mono px-1.5 py-0.5 rounded border",
                      row.db === "PostgreSQL" ? "text-primary border-primary/25 bg-primary/10" :
                      row.db === "MongoDB" ? "text-[var(--status-green)] border-[var(--status-green)]/25 bg-[var(--status-green)]/10" :
                      "text-[var(--status-red)] border-[var(--status-red)]/25 bg-[var(--status-red)]/10"
                    )}>
                      {row.db}
                    </span>
                  </td>
                  <td className="px-4 py-2.5 text-muted-foreground font-mono">{row.fields}</td>
                  <td className="px-4 py-2.5 text-muted-foreground">{row.rel}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
