"use client"

import { useState } from "react"
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
} from "recharts"
import {
  Database,
  Globe,
  Layers,
  Zap,
  Shield,
  Brain,
  CreditCard,
  Bell,
  Server,
  CheckCircle2,
  AlertCircle,
  Clock,
  TrendingUp,
} from "lucide-react"
import { cn } from "@/lib/utils"

const requestData = [
  { time: "00:00", req: 120, err: 2 },
  { time: "03:00", req: 80, err: 1 },
  { time: "06:00", req: 200, err: 5 },
  { time: "09:00", req: 450, err: 8 },
  { time: "12:00", req: 680, err: 12 },
  { time: "15:00", req: 720, err: 9 },
  { time: "18:00", req: 890, err: 14 },
  { time: "21:00", req: 560, err: 7 },
  { time: "Now", req: 430, err: 4 },
]

const latencyData = [
  { route: "/auth", p50: 45, p99: 210 },
  { route: "/rides", p50: 80, p99: 340 },
  { route: "/food", p50: 65, p99: 280 },
  { route: "/driver", p50: 55, p99: 190 },
  { route: "/admin", p50: 70, p99: 320 },
  { route: "/ai", p50: 320, p99: 980 },
]

const techStack = [
  { name: "Node.js 18+", category: "Runtime", color: "text-[var(--status-green)]", bg: "bg-[var(--status-green)]/10 border-[var(--status-green)]/20" },
  { name: "TypeScript", category: "Language", color: "text-primary", bg: "bg-primary/10 border-primary/20" },
  { name: "Express v4", category: "Framework", color: "text-[var(--brand-teal)]", bg: "bg-[var(--brand-teal)]/10 border-[var(--brand-teal)]/20" },
  { name: "PostgreSQL + PostGIS", category: "Primary DB", color: "text-primary", bg: "bg-primary/10 border-primary/20" },
  { name: "MongoDB", category: "Document DB", color: "text-[var(--status-green)]", bg: "bg-[var(--status-green)]/10 border-[var(--status-green)]/20" },
  { name: "Redis", category: "Cache / Pub-Sub", color: "text-[var(--status-red)]", bg: "bg-[var(--status-red)]/10 border-[var(--status-red)]/20" },
  { name: "Socket.io", category: "Real-time", color: "text-[var(--status-amber)]", bg: "bg-[var(--status-amber)]/10 border-[var(--status-amber)]/20" },
  { name: "Prisma ORM", category: "PostgreSQL ORM", color: "text-primary", bg: "bg-primary/10 border-primary/20" },
  { name: "Mongoose", category: "MongoDB ODM", color: "text-[var(--status-green)]", bg: "bg-[var(--status-green)]/10 border-[var(--status-green)]/20" },
  { name: "Stripe / Razorpay", category: "Payments", color: "text-[var(--brand-teal)]", bg: "bg-[var(--brand-teal)]/10 border-[var(--brand-teal)]/20" },
  { name: "Google Maps API", category: "Location", color: "text-[var(--status-amber)]", bg: "bg-[var(--status-amber)]/10 border-[var(--status-amber)]/20" },
  { name: "Gemini AI", category: "AI / ML", color: "text-[var(--status-red)]", bg: "bg-[var(--status-red)]/10 border-[var(--status-red)]/20" },
]

const features = [
  { icon: Shield, label: "JWT + OAuth2 Auth", desc: "Secure authentication with refresh tokens and social login", status: "live" },
  { icon: Globe, label: "Google Maps Integration", desc: "Places, Directions, Distance Matrix & Autocomplete", status: "live" },
  { icon: Brain, label: "Gemini AI", desc: "Chatbot, recommendations, dynamic pricing & sentiment analysis", status: "live" },
  { icon: Zap, label: "Real-time WebSockets", desc: "Socket.io with Redis adapter for horizontal scaling", status: "live" },
  { icon: CreditCard, label: "Payment Processing", desc: "Stripe webhook handling, payment intents, refunds", status: "live" },
  { icon: Bell, label: "Push Notifications", desc: "Firebase Cloud Messaging (FCM) for iOS & Android", status: "live" },
  { icon: Database, label: "PostGIS Spatial Queries", desc: "ST_DWithin for nearby drivers & restaurants", status: "live" },
  { icon: Server, label: "Background Jobs", desc: "node-cron + Bull queue for scheduled tasks", status: "live" },
]

const apiGroups = [
  { prefix: "/api/v1/auth", count: 8, color: "bg-[var(--status-green)]" },
  { prefix: "/api/v1/rides", count: 7, color: "bg-primary" },
  { prefix: "/api/v1/food", count: 8, color: "bg-[var(--status-amber)]" },
  { prefix: "/api/v1/driver", count: 6, color: "bg-[var(--brand-teal)]" },
  { prefix: "/api/v1/admin", count: 9, color: "bg-[var(--status-red)]" },
  { prefix: "/api/v1/ai", count: 4, color: "bg-[var(--status-green)]" },
  { prefix: "/api/v1/payment", count: 3, color: "bg-primary" },
]

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-popover border border-border rounded-md px-3 py-2 text-xs shadow-lg">
        <p className="text-muted-foreground mb-1 font-mono">{label}</p>
        {payload.map((p: any) => (
          <p key={p.name} style={{ color: p.color }} className="font-medium">
            {p.name}: {p.value}
          </p>
        ))}
      </div>
    )
  }
  return null
}

export function OverviewDashboard() {
  const [activeTab, setActiveTab] = useState<"requests" | "latency">("requests")

  return (
    <div className="space-y-6">
      {/* Stats row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { label: "Total Endpoints", value: "45", sub: "Across 7 route groups", icon: Layers, trend: "+3 since v0.9" },
          { label: "Avg Response", value: "82ms", sub: "p50 across all routes", icon: Clock, trend: "p99: 340ms" },
          { label: "WS Events", value: "12", sub: "Real-time event types", icon: Zap, trend: "Socket.io + Redis" },
          { label: "DB Tables", value: "9+", sub: "Prisma + 3 Mongo schemas", icon: Database, trend: "PostGIS enabled" },
        ].map((stat) => (
          <div key={stat.label} className="bg-card border border-border rounded-lg p-4">
            <div className="flex items-start justify-between mb-3">
              <p className="text-xs text-muted-foreground">{stat.label}</p>
              <stat.icon className="w-4 h-4 text-muted-foreground/50 shrink-0" />
            </div>
            <p className="text-2xl font-semibold text-foreground font-mono">{stat.value}</p>
            <p className="text-[11px] text-muted-foreground mt-1">{stat.sub}</p>
            <div className="flex items-center gap-1 mt-2">
              <TrendingUp className="w-3 h-3 text-[var(--status-green)]" />
              <span className="text-[10px] text-[var(--status-green)] font-mono">{stat.trend}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Main chart */}
        <div className="lg:col-span-2 bg-card border border-border rounded-lg p-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-semibold text-foreground">API Traffic</h2>
              <p className="text-[11px] text-muted-foreground mt-0.5">Requests vs Errors (24h simulation)</p>
            </div>
            <div className="flex rounded-md overflow-hidden border border-border">
              {(["requests", "latency"] as const).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={cn(
                    "px-2.5 py-1 text-[11px] font-medium capitalize transition-colors",
                    activeTab === tab
                      ? "bg-primary/15 text-primary"
                      : "text-muted-foreground hover:text-foreground"
                  )}
                >
                  {tab === "requests" ? "Requests" : "Latency"}
                </button>
              ))}
            </div>
          </div>

          {activeTab === "requests" ? (
            <ResponsiveContainer width="100%" height={180}>
              <AreaChart data={requestData} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
                <defs>
                  <linearGradient id="reqGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="oklch(0.6 0.2 250)" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="oklch(0.6 0.2 250)" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="errGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="oklch(0.55 0.22 27)" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="oklch(0.55 0.22 27)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="time" tick={{ fontSize: 10, fill: "oklch(0.52 0 0)" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: "oklch(0.52 0 0)" }} axisLine={false} tickLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Area type="monotone" dataKey="req" name="Requests" stroke="oklch(0.6 0.2 250)" strokeWidth={1.5} fill="url(#reqGrad)" />
                <Area type="monotone" dataKey="err" name="Errors" stroke="oklch(0.55 0.22 27)" strokeWidth={1.5} fill="url(#errGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={latencyData} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
                <XAxis dataKey="route" tick={{ fontSize: 10, fill: "oklch(0.52 0 0)" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: "oklch(0.52 0 0)" }} axisLine={false} tickLine={false} unit="ms" />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="p50" name="p50 (ms)" fill="oklch(0.6 0.2 250)" radius={[2, 2, 0, 0]} />
                <Bar dataKey="p99" name="p99 (ms)" fill="oklch(0.65 0.15 185 / 0.6)" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* API groups */}
        <div className="bg-card border border-border rounded-lg p-4">
          <h2 className="text-sm font-semibold text-foreground mb-1">Route Groups</h2>
          <p className="text-[11px] text-muted-foreground mb-4">Endpoints per module</p>
          <div className="space-y-2.5">
            {apiGroups.map((g) => (
              <div key={g.prefix}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[11px] font-mono text-muted-foreground">{g.prefix}</span>
                  <span className="text-[11px] font-mono text-foreground">{g.count}</span>
                </div>
                <div className="h-1 bg-muted rounded-full overflow-hidden">
                  <div
                    className={cn("h-full rounded-full", g.color)}
                    style={{ width: `${(g.count / 12) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 pt-3 border-t border-border flex items-center justify-between">
            <span className="text-[11px] text-muted-foreground">Total endpoints</span>
            <span className="text-sm font-semibold font-mono text-foreground">45</span>
          </div>
        </div>
      </div>

      {/* Features grid */}
      <div>
        <h2 className="text-sm font-semibold text-foreground mb-3">Core Features</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {features.map((f) => (
            <div key={f.label} className="bg-card border border-border rounded-lg p-3.5 hover:border-primary/30 transition-colors group">
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center justify-center w-8 h-8 rounded-md bg-primary/10 border border-primary/20 group-hover:bg-primary/15 transition-colors">
                  <f.icon className="w-4 h-4 text-primary" />
                </div>
                <div className="flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3 text-[var(--status-green)]" />
                  <span className="text-[10px] text-[var(--status-green)] font-medium">Live</span>
                </div>
              </div>
              <p className="text-xs font-semibold text-foreground mb-1">{f.label}</p>
              <p className="text-[11px] text-muted-foreground leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Tech stack */}
      <div>
        <h2 className="text-sm font-semibold text-foreground mb-3">Technology Stack</h2>
        <div className="flex flex-wrap gap-2">
          {techStack.map((t) => (
            <div
              key={t.name}
              className={cn("flex items-center gap-2 px-3 py-1.5 rounded-full border text-xs", t.bg)}
            >
              <span className={cn("font-semibold", t.color)}>{t.name}</span>
              <span className="text-muted-foreground text-[10px]">{t.category}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Folder structure */}
      <div className="bg-card border border-border rounded-lg p-4">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-semibold text-foreground">Project Structure</h2>
          <span className="text-[10px] font-mono text-muted-foreground bg-muted px-2 py-0.5 rounded">backend/</span>
        </div>
        <div className="code-block p-4 overflow-x-auto">
          <pre className="text-xs leading-relaxed text-muted-foreground">{`backend/
├── src/
│   ├── config/          # env, db, redis, socket
│   ├── controllers/     # request handlers
│   ├── services/        # business logic (ride, order, AI)
│   ├── models/          # Prisma schema + Mongoose models
│   ├── repositories/    # data access layer
│   ├── middleware/      # auth, validation, error handling
│   ├── routes/          # versioned Express routes (/api/v1/...)
│   ├── utils/           # helpers, constants, JWT utils
│   ├── validations/     # Joi/Zod schemas
│   ├── sockets/         # Socket.io event handlers
│   ├── jobs/            # cron + Bull queue workers
│   ├── types/           # TypeScript type definitions
│   └── app.ts           # Express app entry point
├── prisma/              # schema.prisma + migrations
├── tests/               # Jest unit + Supertest integration
├── scripts/             # seed, migration helpers
├── .env.example
├── docker-compose.yml   # PostgreSQL, MongoDB, Redis
├── Dockerfile
└── package.json`}</pre>
        </div>
      </div>
    </div>
  )
}
