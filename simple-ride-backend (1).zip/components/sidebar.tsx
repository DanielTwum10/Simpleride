"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  LayoutDashboard,
  BookOpen,
  GitBranch,
  Zap,
  Shield,
  ChevronRight,
  Menu,
  X,
  Car,
  Circle,
} from "lucide-react"
import { cn } from "@/lib/utils"

const navSections = [
  {
    label: "OVERVIEW",
    items: [
      { href: "/", label: "Dashboard", icon: LayoutDashboard },
    ],
  },
  {
    label: "REFERENCE",
    items: [
      { href: "/api-reference", label: "API Reference", icon: BookOpen },
      { href: "/architecture", label: "Architecture & Schema", icon: GitBranch },
    ],
  },
  {
    label: "IMPLEMENTATION",
    items: [
      { href: "/services", label: "Services & WebSockets", icon: Zap },
      { href: "/security", label: "Security, Jobs & Deploy", icon: Shield },
    ],
  },
]

export function Sidebar() {
  const pathname = usePathname()
  const [mobileOpen, setMobileOpen] = useState(false)

  const NavContent = () => (
    <nav className="flex flex-col h-full">
      {/* Logo */}
      <div className="flex items-center gap-2.5 px-4 py-4 border-b border-border">
        <div className="flex items-center justify-center w-7 h-7 rounded-md bg-primary/20 border border-primary/30">
          <Car className="w-4 h-4 text-primary" />
        </div>
        <div>
          <span className="text-sm font-semibold text-foreground tracking-tight">SIMPLE RIDE</span>
          <div className="flex items-center gap-1.5 mt-0.5">
            <Circle className="w-1.5 h-1.5 fill-[var(--status-green)] text-[var(--status-green)] status-dot-live" />
            <span className="text-[10px] text-muted-foreground font-mono">Backend v1.0.0</span>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <div className="flex-1 overflow-y-auto px-2 py-3 space-y-4">
        {navSections.map((section) => (
          <div key={section.label}>
            <p className="px-2 mb-1.5 text-[10px] font-semibold tracking-widest text-muted-foreground/60 uppercase">
              {section.label}
            </p>
            <div className="space-y-0.5">
              {section.items.map((item) => {
                const active = pathname === item.href
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    onClick={() => setMobileOpen(false)}
                    className={cn(
                      "flex items-center gap-2.5 px-2.5 py-2 rounded-md text-sm transition-all duration-150",
                      active
                        ? "bg-primary/15 text-primary font-medium"
                        : "text-muted-foreground hover:text-foreground hover:bg-secondary"
                    )}
                  >
                    <item.icon className={cn("w-4 h-4 shrink-0", active ? "text-primary" : "text-muted-foreground")} />
                    <span>{item.label}</span>
                    {active && <ChevronRight className="w-3 h-3 ml-auto text-primary/60" />}
                  </Link>
                )
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Footer */}
      <div className="px-4 py-3 border-t border-border">
        <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
          <span className="font-mono">Node.js 18+ · TypeScript · Express v4</span>
        </div>
      </div>
    </nav>
  )

  return (
    <>
      {/* Desktop sidebar */}
      <aside className="hidden md:flex flex-col w-56 shrink-0 h-screen sticky top-0 bg-sidebar border-r border-sidebar-border">
        <NavContent />
      </aside>

      {/* Mobile toggle */}
      <button
        onClick={() => setMobileOpen(true)}
        className="fixed top-3 left-3 z-50 md:hidden flex items-center justify-center w-8 h-8 rounded-md bg-card border border-border text-foreground"
        aria-label="Open menu"
      >
        <Menu className="w-4 h-4" />
      </button>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setMobileOpen(false)}
          />
          <aside className="absolute left-0 top-0 h-full w-56 bg-sidebar border-r border-sidebar-border flex flex-col">
            <button
              onClick={() => setMobileOpen(false)}
              className="absolute top-3 right-3 w-7 h-7 flex items-center justify-center rounded-md bg-secondary text-muted-foreground hover:text-foreground"
              aria-label="Close menu"
            >
              <X className="w-3.5 h-3.5" />
            </button>
            <NavContent />
          </aside>
        </div>
      )}
    </>
  )
}
