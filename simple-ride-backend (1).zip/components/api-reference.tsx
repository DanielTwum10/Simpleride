"use client"

import { useState } from "react"
import { ChevronDown, ChevronRight, Copy, Check } from "lucide-react"
import { cn } from "@/lib/utils"

type Method = "GET" | "POST" | "PUT" | "DELETE" | "PATCH"

interface Endpoint {
  method: Method
  path: string
  summary: string
  auth: boolean
  roles?: string[]
  body?: Record<string, string>
  response?: string
  snippet?: string
}

interface RouteGroup {
  prefix: string
  label: string
  color: string
  endpoints: Endpoint[]
}

const METHOD_COLORS: Record<Method, string> = {
  GET: "text-[var(--status-green)] bg-[var(--status-green)]/10 border-[var(--status-green)]/25",
  POST: "text-primary bg-primary/10 border-primary/25",
  PUT: "text-[var(--status-amber)] bg-[var(--status-amber)]/10 border-[var(--status-amber)]/25",
  PATCH: "text-[var(--brand-teal)] bg-[var(--brand-teal)]/10 border-[var(--brand-teal)]/25",
  DELETE: "text-[var(--status-red)] bg-[var(--status-red)]/10 border-[var(--status-red)]/25",
}

const routeGroups: RouteGroup[] = [
  {
    prefix: "/api/v1/auth",
    label: "Authentication",
    color: "border-[var(--status-green)]/40",
    endpoints: [
      {
        method: "POST", path: "/register", summary: "Register new user or driver. Sends OTP via SMS.", auth: false,
        body: { phone: "string", email: "string?", password: "string", fullName: "string", role: "USER | DRIVER" },
        response: `{ "message": "OTP sent", "userId": "uuid" }`,
        snippet: `const res = await fetch('/api/v1/auth/register', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ phone: '+1234567890', password: 'secret', fullName: 'John Doe', role: 'USER' })
})`
      },
      { method: "POST", path: "/verify-otp", summary: "Verify phone/email OTP and activate account.", auth: false, body: { phone: "string", otp: "string" }, response: `{ "token": "jwt", "refreshToken": "jwt" }` },
      { method: "POST", path: "/login", summary: "Login with phone/email and password. Returns JWT pair.", auth: false, body: { identifier: "string", password: "string" }, response: `{ "accessToken": "jwt", "refreshToken": "jwt", "user": { ... } }` },
      { method: "POST", path: "/social-login", summary: "Google / Facebook OAuth2. Upserts user.", auth: false, body: { provider: "google | facebook", idToken: "string" } },
      { method: "POST", path: "/refresh", summary: "Refresh access token using refresh token.", auth: false, body: { refreshToken: "string" } },
      { method: "POST", path: "/logout", summary: "Invalidate token (blacklist in Redis).", auth: true },
      { method: "GET", path: "/profile", summary: "Get authenticated user profile.", auth: true, response: `{ "id": "uuid", "fullName": "string", "email": "string", ... }` },
      { method: "PUT", path: "/profile", summary: "Update user profile fields.", auth: true, body: { fullName: "string?", profilePic: "string?", deviceToken: "string?" } },
    ]
  },
  {
    prefix: "/api/v1/rides",
    label: "Ride Hailing",
    color: "border-primary/40",
    endpoints: [
      {
        method: "POST", path: "/estimate", summary: "Calculate fare & ETA using Google Maps Distance Matrix.", auth: true,
        body: { pickup: "string | {lat,lng}", dropoff: "string | {lat,lng}", rideType: "motorcycle | car" },
        response: `{ "distance": 12.4, "duration": 22, "fare": 18.50, "currency": "USD" }`,
        snippet: `// services/ride.service.ts
const response = await axios.get(\`https://maps.googleapis.com/maps/api/distancematrix/json\`, {
  params: { origins: pickup, destinations: dropoff, key: process.env.GOOGLE_MAPS_API_KEY }
})
const { distance, duration } = response.data.rows[0].elements[0]
const fare = baseFare + (distance.value / 1000 * perKm) + (duration.value / 60 * perMinute)`
      },
      { method: "POST", path: "/request", summary: "Request a ride. Finds nearby drivers via PostGIS ST_DWithin. Emits Socket.io event.", auth: true, roles: ["USER"], body: { pickup: "{lat,lng}", dropoff: "{lat,lng}", rideType: "motorcycle | car", paymentMethod: "CARD | CASH | WALLET" } },
      { method: "GET", path: "/:id", summary: "Get ride details including driver location and status.", auth: true },
      { method: "POST", path: "/:id/cancel", summary: "Cancel a ride. Triggers refund if already charged.", auth: true, body: { reason: "string?" } },
      { method: "GET", path: "/history", summary: "Paginated user ride history with filters.", auth: true },
      { method: "POST", path: "/:id/rate", summary: "Rate driver 1–5 stars with optional comment.", auth: true, roles: ["USER"], body: { rating: "1-5", comment: "string?" } },
      { method: "GET", path: "/active", summary: "Get current active ride for authenticated user.", auth: true },
    ]
  },
  {
    prefix: "/api/v1/food",
    label: "Food Delivery",
    color: "border-[var(--status-amber)]/40",
    endpoints: [
      { method: "GET", path: "/restaurants", summary: "List nearby restaurants. Uses PostGIS for geo-filtering.", auth: true, body: { lat: "number", lng: "number", radius: "number?", cuisine: "string?", sortBy: "rating | distance | price" } },
      { method: "GET", path: "/restaurants/:id", summary: "Restaurant details, rating, opening hours.", auth: true },
      { method: "GET", path: "/restaurants/:id/menu", summary: "Full menu grouped by category with availability.", auth: true },
      { method: "POST", path: "/orders", summary: "Place a food order. Validates items and calculates totals.", auth: true, roles: ["USER"], body: { restaurantId: "uuid", items: "[{menuItemId, qty, customization}]", deliveryAddress: "string", paymentMethod: "CARD | CASH | WALLET" } },
      { method: "GET", path: "/orders/:id", summary: "Order details including real-time driver location.", auth: true },
      { method: "GET", path: "/orders/history", summary: "Paginated order history.", auth: true },
      { method: "POST", path: "/orders/:id/cancel", summary: "Cancel order if status is PENDING or CONFIRMED.", auth: true },
      { method: "POST", path: "/orders/:id/rate", summary: "Rate restaurant and/or delivery driver.", auth: true, roles: ["USER"] },
    ]
  },
  {
    prefix: "/api/v1/driver",
    label: "Driver Portal",
    color: "border-[var(--brand-teal)]/40",
    endpoints: [
      { method: "GET", path: "/requests", summary: "Get pending ride/delivery requests within 5km radius.", auth: true, roles: ["DRIVER"] },
      { method: "POST", path: "/accept/:rideId", summary: "Accept a ride request. Updates driver status.", auth: true, roles: ["DRIVER"] },
      { method: "POST", path: "/reject/:rideId", summary: "Reject ride. System re-broadcasts to next driver.", auth: true, roles: ["DRIVER"] },
      { method: "POST", path: "/location", summary: "Update current GPS coordinates. Stored in MongoDB LocationLog.", auth: true, roles: ["DRIVER"], body: { lat: "number", lng: "number", rideId: "uuid?" } },
      { method: "GET", path: "/earnings", summary: "Earnings summary by day/week/month with trip breakdown.", auth: true, roles: ["DRIVER"] },
      { method: "POST", path: "/status", summary: "Toggle online/offline availability.", auth: true, roles: ["DRIVER"], body: { isOnline: "boolean" } },
    ]
  },
  {
    prefix: "/api/v1/admin",
    label: "Admin Panel",
    color: "border-[var(--status-red)]/40",
    endpoints: [
      { method: "GET", path: "/users", summary: "List all users with filters (role, verified, date).", auth: true, roles: ["ADMIN"] },
      { method: "GET", path: "/drivers", summary: "List all drivers with verification status.", auth: true, roles: ["ADMIN"] },
      { method: "POST", path: "/drivers/:id/verify", summary: "Approve/reject driver after document review.", auth: true, roles: ["ADMIN"] },
      { method: "GET", path: "/restaurants", summary: "Manage restaurant listings.", auth: true, roles: ["ADMIN"] },
      { method: "POST", path: "/restaurants", summary: "Onboard new restaurant with commission rate.", auth: true, roles: ["ADMIN"] },
      { method: "GET", path: "/analytics/revenue", summary: "Revenue breakdown by period, ride type, food orders.", auth: true, roles: ["ADMIN"] },
      { method: "GET", path: "/analytics/users", summary: "User growth and retention metrics.", auth: true, roles: ["ADMIN"] },
      { method: "GET", path: "/rides/active", summary: "All currently active rides with live map data.", auth: true, roles: ["ADMIN"] },
      { method: "DELETE", path: "/users/:id", summary: "Soft-delete / ban user account.", auth: true, roles: ["ADMIN"] },
    ]
  },
  {
    prefix: "/api/v1/ai",
    label: "AI Features",
    color: "border-[var(--status-green)]/40",
    endpoints: [
      { method: "POST", path: "/chat", summary: "Gemini AI chatbot. Returns contextual assistant response.", auth: true, body: { message: "string", conversationId: "string?" } },
      { method: "GET", path: "/recommendations", summary: "Personalized restaurant & ride suggestions.", auth: true },
      { method: "POST", path: "/pricing/estimate", summary: "Dynamic pricing via Gemini demand prediction.", auth: true, body: { pickup: "{lat,lng}", rideType: "string", timestamp: "ISO8601" } },
      { method: "POST", path: "/sentiment", summary: "Analyze review sentiment for moderation.", auth: true, roles: ["ADMIN"] },
    ]
  },
  {
    prefix: "/api/v1/payment",
    label: "Payments",
    color: "border-primary/40",
    endpoints: [
      { method: "POST", path: "/create-intent", summary: "Create Stripe PaymentIntent. Returns clientSecret.", auth: true, body: { amount: "number (cents)", currency: "string", rideId: "uuid?", orderId: "uuid?" } },
      { method: "POST", path: "/webhook", summary: "Stripe webhook. Verifies signature, updates payment status.", auth: false },
      { method: "GET", path: "/history", summary: "User payment history with pagination.", auth: true },
    ]
  },
]

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false)
  const copy = () => {
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }
  return (
    <button onClick={copy} className="flex items-center justify-center w-6 h-6 rounded text-muted-foreground hover:text-foreground transition-colors">
      {copied ? <Check className="w-3 h-3 text-[var(--status-green)]" /> : <Copy className="w-3 h-3" />}
    </button>
  )
}

function EndpointRow({ ep, prefix }: { ep: Endpoint; prefix: string }) {
  const [open, setOpen] = useState(false)
  const fullPath = prefix + ep.path

  return (
    <div className={cn("border-b border-border last:border-0", open && "bg-secondary/30")}>
      <button
        className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-secondary/20 transition-colors"
        onClick={() => setOpen(!open)}
      >
        <span className={cn("text-[11px] font-semibold font-mono px-1.5 py-0.5 rounded border min-w-[46px] text-center", METHOD_COLORS[ep.method])}>
          {ep.method}
        </span>
        <span className="text-xs font-mono text-foreground flex-1">{fullPath}</span>
        <span className="text-[11px] text-muted-foreground hidden sm:block flex-1">{ep.summary}</span>
        {ep.auth && (
          <span className="text-[10px] font-mono px-1.5 py-0.5 rounded border border-[var(--status-amber)]/30 text-[var(--status-amber)] bg-[var(--status-amber)]/10">
            AUTH
          </span>
        )}
        {ep.roles && ep.roles.map(r => (
          <span key={r} className="text-[10px] font-mono px-1.5 py-0.5 rounded border border-border text-muted-foreground">
            {r}
          </span>
        ))}
        {open ? <ChevronDown className="w-3.5 h-3.5 text-muted-foreground shrink-0" /> : <ChevronRight className="w-3.5 h-3.5 text-muted-foreground shrink-0" />}
      </button>

      {open && (
        <div className="px-4 pb-4 space-y-3">
          <p className="text-xs text-muted-foreground">{ep.summary}</p>

          {ep.body && (
            <div>
              <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide mb-2">Request Body</p>
              <div className="code-block p-3">
                <pre className="text-xs text-muted-foreground">{`{\n${Object.entries(ep.body).map(([k, v]) => `  "${k}": ${v}`).join(",\n")}\n}`}</pre>
              </div>
            </div>
          )}

          {ep.response && (
            <div>
              <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide mb-2">Response 200</p>
              <div className="code-block p-3">
                <pre className="text-xs text-[var(--status-green)]">{ep.response}</pre>
              </div>
            </div>
          )}

          {ep.snippet && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wide">Code Snippet</p>
                <CopyButton text={ep.snippet} />
              </div>
              <div className="code-block p-3">
                <pre className="text-xs text-foreground/80">{ep.snippet}</pre>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

function GroupCard({ group }: { group: RouteGroup }) {
  const [expanded, setExpanded] = useState(true)

  return (
    <div className={cn("bg-card border rounded-lg overflow-hidden", group.color)}>
      <button
        className="w-full flex items-center justify-between px-4 py-3 hover:bg-secondary/20 transition-colors"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="flex items-center gap-3">
          {expanded ? <ChevronDown className="w-4 h-4 text-muted-foreground" /> : <ChevronRight className="w-4 h-4 text-muted-foreground" />}
          <span className="text-sm font-semibold text-foreground">{group.label}</span>
          <span className="text-xs font-mono text-muted-foreground">{group.prefix}</span>
        </div>
        <span className="text-[11px] font-mono bg-muted border border-border text-muted-foreground px-2 py-0.5 rounded">
          {group.endpoints.length} endpoints
        </span>
      </button>
      {expanded && (
        <div className="border-t border-border">
          {group.endpoints.map((ep) => (
            <EndpointRow key={ep.method + ep.path} ep={ep} prefix={group.prefix} />
          ))}
        </div>
      )}
    </div>
  )
}

export function ApiReference() {
  const [filter, setFilter] = useState<string>("all")

  const filtered = filter === "all" ? routeGroups : routeGroups.filter(g => g.prefix.includes(filter))

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-base font-semibold text-foreground">REST API Reference</h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            Base URL: <code className="font-mono text-primary">https://api.simpleride.app/api/v1</code>
            <span className="ml-2 text-muted-foreground/60">· Bearer token required for authenticated routes</span>
          </p>
        </div>
        <div className="flex items-center gap-1.5 flex-wrap">
          {["all", "auth", "rides", "food", "driver", "admin", "ai"].map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                "px-2.5 py-1 text-[11px] font-medium rounded capitalize transition-colors border",
                filter === f
                  ? "bg-primary/15 text-primary border-primary/30"
                  : "text-muted-foreground border-border hover:text-foreground hover:border-border/70"
              )}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* Auth note */}
      <div className="flex items-start gap-2.5 px-4 py-3 bg-[var(--status-amber)]/5 border border-[var(--status-amber)]/20 rounded-lg">
        <span className="text-[var(--status-amber)] text-xs font-mono mt-0.5">AUTH</span>
        <p className="text-xs text-muted-foreground leading-relaxed">
          All authenticated endpoints require <code className="font-mono text-foreground">Authorization: Bearer &lt;accessToken&gt;</code> header.
          Access tokens expire in <strong className="text-foreground">15 minutes</strong>.
          Use <code className="font-mono text-primary">POST /auth/refresh</code> with your refresh token to obtain a new pair.
        </p>
      </div>

      {/* Groups */}
      <div className="space-y-3">
        {filtered.map(g => <GroupCard key={g.prefix} group={g} />)}
      </div>
    </div>
  )
}
