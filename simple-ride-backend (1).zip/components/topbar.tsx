"use client"

import { useState } from "react"
import { Search, Bell, ExternalLink } from "lucide-react"

interface TopbarProps {
  title: string
  subtitle?: string
  badge?: string
}

export function Topbar({ title, subtitle, badge }: TopbarProps) {
  const [searchOpen, setSearchOpen] = useState(false)

  return (
    <header className="sticky top-0 z-30 flex items-center justify-between px-5 py-3 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="flex items-center gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-sm font-semibold text-foreground">{title}</h1>
            {badge && (
              <span className="px-1.5 py-0.5 text-[10px] font-semibold rounded font-mono bg-primary/15 text-primary border border-primary/25">
                {badge}
              </span>
            )}
          </div>
          {subtitle && (
            <p className="text-[11px] text-muted-foreground mt-0.5">{subtitle}</p>
          )}
        </div>
      </div>

      <div className="flex items-center gap-2">
        {searchOpen ? (
          <input
            autoFocus
            onBlur={() => setSearchOpen(false)}
            className="w-48 px-2.5 py-1.5 text-xs bg-input border border-border rounded-md text-foreground placeholder:text-muted-foreground outline-none focus:border-primary/50 transition-all"
            placeholder="Search endpoints..."
          />
        ) : (
          <button
            onClick={() => setSearchOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs text-muted-foreground bg-secondary border border-border rounded-md hover:text-foreground hover:border-border/80 transition-all"
          >
            <Search className="w-3 h-3" />
            <span>Search</span>
            <kbd className="ml-1 px-1 py-0.5 text-[9px] font-mono bg-muted rounded border border-border">⌘K</kbd>
          </button>
        )}
        <button className="flex items-center justify-center w-7 h-7 rounded-md bg-secondary border border-border text-muted-foreground hover:text-foreground transition-colors">
          <Bell className="w-3.5 h-3.5" />
        </button>
        <a
          href="https://github.com"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs bg-primary text-primary-foreground rounded-md hover:opacity-90 transition-opacity font-medium"
        >
          <ExternalLink className="w-3 h-3" />
          <span>GitHub</span>
        </a>
      </div>
    </header>
  )
}
