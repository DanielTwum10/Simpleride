import { Sidebar } from "@/components/sidebar"
import { Topbar } from "@/components/topbar"
import { ServicesPage } from "@/components/services-page"

export default function Services() {
  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <Topbar
          title="Services & WebSockets"
          subtitle="Business logic, Google Maps, Gemini AI, Payments, FCM & Socket.io"
          badge="Real-time"
        />
        <main className="flex-1 px-5 py-6">
          <ServicesPage />
        </main>
      </div>
    </div>
  )
}
