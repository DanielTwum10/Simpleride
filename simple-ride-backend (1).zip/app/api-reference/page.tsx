import { Sidebar } from "@/components/sidebar"
import { Topbar } from "@/components/topbar"
import { ApiReference } from "@/components/api-reference"

export default function ApiReferencePage() {
  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <Topbar
          title="API Reference"
          subtitle="REST endpoints — /api/v1/..."
          badge="OpenAPI 3.0"
        />
        <main className="flex-1 px-5 py-6">
          <ApiReference />
        </main>
      </div>
    </div>
  )
}
