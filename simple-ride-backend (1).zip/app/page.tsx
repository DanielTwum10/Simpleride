import { Sidebar } from "@/components/sidebar"
import { Topbar } from "@/components/topbar"
import { OverviewDashboard } from "@/components/overview-dashboard"

export default function Home() {
  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <Topbar
          title="Dashboard"
          subtitle="SIMPLE RIDE — Backend Architecture Overview"
          badge="v1.0.0"
        />
        <main className="flex-1 px-5 py-6">
          <OverviewDashboard />
        </main>
      </div>
    </div>
  )
}
