import { Sidebar } from "@/components/sidebar"
import { Topbar } from "@/components/topbar"
import { ArchitecturePage } from "@/components/architecture-page"

export default function Architecture() {
  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <Topbar
          title="Architecture & Schema"
          subtitle="System design, database models and data flow"
          badge="PostGIS + MongoDB"
        />
        <main className="flex-1 px-5 py-6">
          <ArchitecturePage />
        </main>
      </div>
    </div>
  )
}
