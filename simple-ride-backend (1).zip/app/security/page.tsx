import { Sidebar } from "@/components/sidebar"
import { Topbar } from "@/components/topbar"
import { SecurityPage } from "@/components/security-page"

export default function Security() {
  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <Topbar
          title="Security, Jobs & Deployment"
          subtitle="Middleware, background jobs, testing, Docker & CI/CD"
          badge="Production"
        />
        <main className="flex-1 px-5 py-6">
          <SecurityPage />
        </main>
      </div>
    </div>
  )
}
